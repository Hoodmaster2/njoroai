```markdown
# NJORO AI - Production Autonomous Desktop AI System

## Core Philosophy
NJORO AI is a personal autonomous desktop operator that runs a continuous Sense → Plan → Act → Evaluate loop. The SQLite database is the single source of truth for all state, goals, journals, and confirmations. All operations are idempotent, crash-safe, and restart-resistant. High-risk actions require explicit user confirmation, with confirmation state persisting across application restarts. The system uses Gemini API for silent planning (LLM reasoning is never displayed to the user). The UI is built with PyQt6 using a dark cyber theme (Magenta #FF00FF, Purple #9400D3 on Background #1E1E1E).

## System Architecture

### Folder Structure
```
src/
    main.py                          # Application entry point
    agent/
        loop.py                      # Main agent loop (Sense→Plan→Act→Evaluate)
        llm_client.py                 # Gemini API client for silent planning
    persistence/
        database.py                   # SQLite connection manager
        models.py                      # Data models and table definitions
    tools/
        registry.py                    # Tool registry with idempotent execution
        builtin.py                     # Built-in tools (file, web, system)
    ui/
        main_window.py                 # PyQt6 main window
        theme.py                        # Dark cyber theme definitions
    utils/
        config.py                       # Configuration loader (.env)
        logger.py                        # Logging setup
requirements.txt
.env.example
FILE_INDEX.json                        # Build tracking (completed files)
PROJECT_PROGRESS.md                     # Daily build log
README.md
```

### Database Schema Requirements
**File:** `src/persistence/models.py`
**File:** `src/persistence/database.py`

Create the following tables on startup if they don't exist. All operations must be transactional.

| Table | Columns | Description |
|-------|---------|-------------|
| `tools` | `id` INTEGER PRIMARY KEY, `name` TEXT UNIQUE, `description` TEXT, `code` TEXT, `enabled` BOOLEAN DEFAULT 1 | Registered tools |
| `state` | `key` TEXT PRIMARY KEY, `value` TEXT | Agent state (current goal, mode) |
| `goals` | `id` INTEGER PRIMARY KEY, `description` TEXT, `status` TEXT, `created_at` DATETIME | Goals with status (pending, active, completed, failed) |
| `journal` | `id` INTEGER PRIMARY KEY, `timestamp` DATETIME, `goal_id` INTEGER, `action` TEXT, `tool_used` TEXT, `result` TEXT, `status` TEXT | Execution journal |
| `confirmations` | `action_hash` TEXT PRIMARY KEY, `goal_id` INTEGER, `action_description` TEXT, `approved` BOOLEAN, `expiry` DATETIME | Persistent confirmation cache |

### Agent Loop Requirements
**File:** `src/agent/loop.py`
**File:** `src/agent/llm_client.py`

The agent runs in an async loop within a QThread to prevent UI freezing.

1. **Sense:** Query current active goal from `goals` table.
2. **Plan:** Call Gemini API (via `llm_client.py`) with goal, recent journal history, and available tools. Generate next action/tool call. LLM reasoning is silent (never displayed).
3. **Act:**
   - Parse action from LLM response.
   - If tool call: Look up in `tools` registry.
   - Check `confirmations` table for action hash.
   - If approved and not expired: Execute tool (idempotently).
   - If not approved: Send to UI for user confirmation, store in `confirmations`, pause loop.
4. **Evaluate:** Log result in `journal`. Update goal status if criteria met.

### Tool Registry Requirements
**File:** `src/tools/registry.py`
**File:** `src/tools/builtin.py`

- Tools must be registered with name, description, and async function.
- All tool functions must be idempotent (safe to re-run with same inputs).
- Tools can be enabled/disabled via `tools` table.
- Built-in tools: file operations, web requests, system commands (sandboxed).

### UI Requirements
**File:** `src/ui/main_window.py`
**File:** `src/ui/theme.py`

- **Main Window:** QMainWindow with dark cyber theme.
- **Colors:** Background #1E1E1E, Text/Buttons Magenta #FF00FF, Accents Purple #9400D3.
- **Left Panel:** QTextEdit for goal input, QPushButton "Start/Resume Agent".
- **Center Panel:** QTableWidget showing live journal updates.
- **Right Panel:** QListWidget for pending confirmations, Approve/Reject buttons.
- **Status Bar:** Current agent state (Idle, Planning, Waiting for Approval, Executing).
- All UI updates must be thread-safe (signals/slots).

### Utilities
**File:** `src/utils/config.py` - Load `.env` using python-dotenv.
**File:** `src/utils/logger.py` - Log to file and rotate.

## Daily Continuation Mode (CRITICAL)

### Build Tracking Protocol

Before generating any file, Gemini CLI MUST:

1. **Check for FILE_INDEX.json:**
   - If exists: Read `completed_files` array.
   - If not exists: Create FILE_INDEX.json with `{"completed_files": []}`.

2. **Determine Generation Scope:**
   - Generate ONLY files NOT in `completed_files`.
   - Follow folder structure exactly.
   - Skip all completed files entirely.

3. **During Generation:**
   - After each file is successfully generated:
     - Append file path to `completed_files` in FILE_INDEX.json.
     - Append one-line summary to PROJECT_PROGRESS.md (e.g., `2024-01-01: Generated src/main.py`).
     - Save FILE_INDEX.json immediately.

4. **On Interruption/Token Limit:**
   - Stop gracefully after current file.
   - On next run, resume from first missing file.

5. **NEVER:**
   - Regenerate completed files.
   - Modify completed files unless explicitly instructed.
   - Overwrite user modifications.

## Output Format Rules

All file outputs MUST use the exact separator format:

```
===== FILE: path/to/file.py =====
[file content here]
```

**Rules:**
- No explanations outside file separators.
- No summaries of what was generated.
- No TODO comments.
- No `pass` statements.
- No pseudocode or placeholders.
- All functions fully implemented with error handling.
- All imports explicitly included.
- Include `if __name__ == "__main__":` block in `src/main.py`.
- Use async agent loop in QThread.
- Database operations inside transactions.
- All tool functions idempotent.

## Strict Constraints

1. **Production Grade:**
   - Full error handling (try/except with logging).
   - Type hints where appropriate.
   - Resource cleanup (files, DB connections).
   - Thread safety for UI updates.

2. **Windows Compatibility:**
   - Use pathlib for paths.
   - Proper newline handling.
   - Avoid Unix-specific features.

3. **Persistence:**
   - Database is source of truth.
   - Confirmation cache survives restarts.
   - Agent state survives crashes.

4. **Idempotency:**
   - Running same action twice produces same outcome.
   - No duplicate journal entries.
   - No side effects on re-run.

5. **Silent Reasoning:**
   - LLM planning calls never displayed.
   - Only actions and results shown.

## Self-Validation Requirement

Before completing generation (or pausing due to limits), Gemini CLI MUST internally verify:

- [ ] All files listed in architecture exist in FILE_INDEX.json.
- [ ] No file in FILE_INDEX.json is empty.
- [ ] No file contains `# TODO`, `pass`, or `...` placeholders.
- [ ] All functions have implementation bodies.
- [ ] All imports are valid.
- [ ] `src/main.py` contains `if __name__ == "__main__":` with initialization.
- [ ] Database initialization code exists in `src/persistence/database.py`.
- [ ] QThread implementation for agent loop exists.
- [ ] Dark cyber theme constants defined in `theme.py`.
- [ ] README.md contains Windows setup instructions (venv, install, .env, run).

If validation fails, correct the issue before proceeding.

## Final Notes

- This build system is deterministic and resumable.
- Always respect FILE_INDEX.json.
- Never regenerate completed work.
- Focus on production-grade quality.
- Output only files with separators.
- No commentary outside file blocks.

BEGIN GENERATION NOW.
```